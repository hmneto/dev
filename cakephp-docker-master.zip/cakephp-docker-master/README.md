# docker build -t createcake .
# docker run -d -p 80:80 createcake
# docker exec -it createcake bash