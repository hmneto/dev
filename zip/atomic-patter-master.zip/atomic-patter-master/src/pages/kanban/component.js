import React, { Component } from 'react';
export class KanbanComponent extends Component {

    render() { 
        return ( 
            <h1>Kanban Component</h1>
         );
    }
}