import React from 'react';
import { Route } from "react-router-dom";
import { KanbanComponent } from "./component";
export const route = <Route exact component={KanbanComponent} path="/kanban" key="kanban"/>