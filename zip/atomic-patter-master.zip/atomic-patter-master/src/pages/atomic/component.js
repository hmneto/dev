import React, { Component } from 'react';
export class AtomicComponent extends Component {

    render() { 
        return ( 
            <h1>Atomic Component</h1>
         );
    }
}