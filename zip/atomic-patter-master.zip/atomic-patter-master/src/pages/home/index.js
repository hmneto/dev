import React from 'react';
import { Route } from "react-router-dom";
import { HomeComponent } from "./component";
export const route = <Route exact component={HomeComponent} path="/home" key="home"></Route>