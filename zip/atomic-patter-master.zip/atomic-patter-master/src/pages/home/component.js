import React, { Component } from 'react';
export class HomeComponent extends Component {

    render() { 
        return ( 
            <h1>Home Component</h1>
         );
    }
}