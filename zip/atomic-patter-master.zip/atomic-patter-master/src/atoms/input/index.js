import React, { Component } from 'react';

export class Input extends Component {
    state = {}
    render() {
        return (
            <input type="text" className="form-control" />
        );
    }
}
