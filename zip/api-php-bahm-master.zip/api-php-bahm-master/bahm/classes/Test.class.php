<?php

class Test{
    public function teste()
    {
        echo getenv("database");
    }
}