# cd create-react-app-docker && docker build -t create-react .
# docker run -it -p 3000:3000 create-react bash
